
#include <fli.h>
#include <forms.h>

int fli_apply_geometry (FL_FORM *form, char const *geom)
{
    int
	parseres,
	x, y, w, h;

    parseres = fli_parse_geometry (geom, &x, &y, &w, &h);
    if (parseres == FLI_WHXY_PARSED)
	fl_set_form_geometry (form, x, y, w, h);
    else if (parseres == FLI_XY_PARSED)
	fl_set_form_position (form, x, y);
    else if (parseres == FLI_WH_PARSED)
	fl_set_form_size (form, w, h);

    return (parseres);
}
