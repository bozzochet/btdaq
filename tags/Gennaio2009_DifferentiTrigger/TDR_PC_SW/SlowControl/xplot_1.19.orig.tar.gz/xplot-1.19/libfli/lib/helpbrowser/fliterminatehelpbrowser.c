
#include <fli.h>
#include <stdio.h> 

void fli_terminate_help_browser (FL_OBJECT *ob)
{
    register int
	i;

    /* search for that object, close the file */
    for (i = 0; i < nfli_help_browser; i++)
	if (fli_help_browser [i].textbrowser == ob ||
	    fli_help_browser [i].contentsbrowser == ob ||
	    fli_help_browser [i].indexbrowser == ob
	   )
	    fclose (fli_help_browser [i].f);
}
