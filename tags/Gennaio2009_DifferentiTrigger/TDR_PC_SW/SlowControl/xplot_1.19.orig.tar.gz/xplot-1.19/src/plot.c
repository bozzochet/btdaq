/* Form definition file generated with fdesign. */

#include <X11/forms.h>
#include <stdlib.h>
#include "plot.h"

FL_FORM *plot;

FL_OBJECT
        *small_plot,
        *autoredraw_button,
        *linetype_guess,
        *miny_slider,
        *maxy_slider,
        *minx_slider,
        *maxx_slider,
        *minx_input,
        *maxx_input,
        *miny_input,
        *maxy_input,
        *activate_button,
        *help_button;

void create_form_plot(void)
{
  FL_OBJECT *obj;

  if (plot)
     return;

  plot = fl_bgn_form(FL_NO_BOX,390,360);
  obj = fl_add_box(FL_FLAT_BOX,0,0,390,360,"");
    fl_set_object_color(obj,FL_DARKCYAN,FL_COL1);
  obj = fl_add_text(FL_NORMAL_TEXT,275,5,110,30,"XPlot !");
    fl_set_object_color(obj,FL_DARKCYAN,FL_DOGERBLUE);
    fl_set_object_lcol(obj,FL_BLUE);
    fl_set_object_lsize(obj,FL_HUGE_SIZE);
    fl_set_object_lalign(obj,FL_ALIGN_CENTER|FL_ALIGN_INSIDE);
    fl_set_object_lstyle(obj,FL_TIMESITALIC_STYLE+FL_EMBOSSED_STYLE);
  obj = fl_add_box(FL_UP_BOX,275,90,110,75,"");
  obj = fl_add_box(FL_UP_BOX,5,305,265,50,"");
  obj = fl_add_box(FL_UP_BOX,5,5,265,295,"");
  small_plot = obj = fl_add_xyplot(FL_NORMAL_XYPLOT,50,10,215,215,"");
    fl_set_object_boxtype(obj,FL_DOWN_BOX);
    fl_set_object_color(obj,FL_MCOL,FL_BLACK);
  obj = fl_add_text(FL_NORMAL_TEXT,295,95,70,15,"Line types");
    fl_set_object_lsize(obj,FL_NORMAL_SIZE);
    fl_set_object_lalign(obj,FL_ALIGN_LEFT|FL_ALIGN_INSIDE);
  obj = fl_add_button(FL_NORMAL_BUTTON,275,260,110,20,"Redraw now");
    fl_set_button_shortcut(obj,"^L",1);
    fl_set_object_callback(obj,redraw_plots,0);
  autoredraw_button = obj = fl_add_checkbutton(FL_PUSH_BUTTON,275,240,110,20,"Auto-redraw");
    fl_set_object_boxtype(obj,FL_UP_BOX);
    fl_set_object_callback(obj,set_autoredraw,0);
  obj = fl_add_button(FL_NORMAL_BUTTON,275,215,110,20,"Scale Y");
    fl_set_object_callback(obj,guess_y,0);
  linetype_guess = obj = fl_add_checkbutton(FL_RADIO_BUTTON,275,115,110,15,"solid or circles");
    fl_set_object_callback(obj,setlinetype,LINETYPE_GUESS);
  obj = fl_add_checkbutton(FL_RADIO_BUTTON,275,125,110,15,"solid");
    fl_set_object_callback(obj,setlinetype,FL_NORMAL_XYPLOT);
  obj = fl_add_checkbutton(FL_RADIO_BUTTON,275,135,105,15,"solid with circles");
    fl_set_object_callback(obj,setlinetype,FL_CIRCLE_XYPLOT);
  obj = fl_add_checkbutton(FL_RADIO_BUTTON,275,145,110,15,"solid with squares");
    fl_set_object_callback(obj,setlinetype,FL_SQUARE_XYPLOT);
  miny_slider = obj = fl_add_slider(FL_VERT_SLIDER,10,10,20,215,"");
    fl_set_object_callback(obj,setrange,SET_MINY);
     fl_set_slider_return(obj, FL_RETURN_CHANGED);
  maxy_slider = obj = fl_add_slider(FL_VERT_SLIDER,30,10,20,215,"");
    fl_set_object_callback(obj,setrange,SET_MAXY);
     fl_set_slider_return(obj, FL_RETURN_CHANGED);
  minx_slider = obj = fl_add_slider(FL_HOR_SLIDER,50,225,215,20,"");
    fl_set_object_callback(obj,setrange,SET_MINX);
     fl_set_slider_return(obj, FL_RETURN_CHANGED);
  maxx_slider = obj = fl_add_slider(FL_HOR_SLIDER,50,245,215,20,"");
    fl_set_object_callback(obj,setrange,SET_MAXX);
     fl_set_slider_return(obj, FL_RETURN_CHANGED);
  minx_input = obj = fl_add_input(FL_FLOAT_INPUT,25,310,100,20,"x");
    fl_set_object_boxtype(obj,FL_FLAT_BOX);
    fl_set_object_color(obj,FL_MCOL,FL_COL1);
    fl_set_object_callback(obj,setboundary,SET_MINX);
  maxx_input = obj = fl_add_input(FL_FLOAT_INPUT,165,310,100,20,"to");
    fl_set_object_boxtype(obj,FL_FLAT_BOX);
    fl_set_object_color(obj,FL_COL1,FL_COL1);
    fl_set_object_callback(obj,setboundary,SET_MAXX);
  miny_input = obj = fl_add_input(FL_FLOAT_INPUT,25,330,100,20,"y");
    fl_set_object_boxtype(obj,FL_FLAT_BOX);
    fl_set_object_color(obj,FL_COL1,FL_COL1);
    fl_set_object_callback(obj,setboundary,SET_MINY);
  maxy_input = obj = fl_add_input(FL_FLOAT_INPUT,165,330,100,20,"to");
    fl_set_object_boxtype(obj,FL_FLAT_BOX);
    fl_set_object_color(obj,FL_COL1,FL_COL1);
    fl_set_object_callback(obj,setboundary,SET_MAXY);
  activate_button = obj = fl_add_button(FL_NORMAL_BUTTON,275,65,110,20,"(De) activate sets");
    fl_set_object_callback(obj,activate_sets,0);
  help_button = obj = fl_add_button(FL_NORMAL_BUTTON,275,40,110,20,"Help / About..");
    fl_set_object_callback(obj,dohelp,0);
  obj = fl_add_input(FL_NORMAL_INPUT,50,270,215,25,"Title");
    fl_set_object_callback(obj,settitle,0);
  obj = fl_add_button(FL_NORMAL_BUTTON,275,290,110,65,"Dismiss (Esc)");
    fl_set_button_shortcut(obj,"^[",1);
    fl_set_object_lsize(obj,FL_NORMAL_SIZE);
    fl_set_object_callback(obj,quit,0);
  obj = fl_add_button(FL_NORMAL_BUTTON,275,170,110,20,"Static blowup");
    fl_set_object_callback(obj,do_blowup,STATIC_BLOWUP);
  obj = fl_add_button(FL_NORMAL_BUTTON,275,190,110,20,"Dynamic blowup");
    fl_set_object_callback(obj,do_blowup,DYNAMIC_BLOWUP);
  fl_end_form();

}
/*---------------------------------------*/

FL_FORM *blowup;

FL_OBJECT
        *blowup_plot,
        *blowup_quit;

void create_form_blowup(void)
{
  FL_OBJECT *obj;

  if (blowup)
     return;

  blowup = fl_bgn_form(FL_NO_BOX,380,330);
  obj = fl_add_box(FL_FLAT_BOX,0,0,380,330,"");
    fl_set_object_color(obj,FL_WHITE,FL_COL1);
  blowup_plot = obj = fl_add_xyplot(FL_NORMAL_XYPLOT,0,0,380,330,"");
    fl_set_object_color(obj,FL_WHITE,FL_BLACK);
  blowup_quit = obj = fl_add_button(FL_NORMAL_BUTTON,0,0,380,330,"");
    fl_set_object_boxtype(obj,FL_NO_BOX);
    fl_set_object_color(obj,FL_WHITE,FL_COL1);
    fl_set_object_callback(obj,quitblowup,0);
  fl_end_form();

}
/*---------------------------------------*/

FL_FORM *activator;

FL_OBJECT
        *activate_browser;

void create_form_activator(void)
{
  FL_OBJECT *obj;

  if (activator)
     return;

  activator = fl_bgn_form(FL_NO_BOX,140,205);
  obj = fl_add_box(FL_FLAT_BOX,0,0,140,205,"");
    fl_set_object_color(obj,FL_DARKCYAN,FL_COL1);
  activate_browser = obj = fl_add_browser(FL_SELECT_BROWSER,5,5,130,170,"");
    fl_set_object_color(obj,FL_DARKCYAN,FL_YELLOW);
    fl_set_object_lstyle(obj,FL_FIXED_STYLE);
    fl_set_object_callback(obj,setactive,0);
  obj = fl_add_button(FL_NORMAL_BUTTON,25,180,110,20,"Dismiss");
    fl_set_object_callback(obj,activator_done,0);
  fl_end_form();

}
/*---------------------------------------*/

FL_FORM *help;

FL_OBJECT
        *help_browser,
        *help_contents_browser,
        *help_index_browser;

void create_form_help(void)
{
  FL_OBJECT *obj;

  if (help)
     return;

  help = fl_bgn_form(FL_NO_BOX,435,470);
  obj = fl_add_box(FL_FLAT_BOX,0,0,435,470,"");
    fl_set_object_color(obj,FL_DARKCYAN,FL_COL1);
  obj = fl_add_button(FL_NORMAL_BUTTON,340,445,90,20,"Done");
    fl_set_object_callback(obj,help_done,0);
  help_browser = obj = fl_add_browser(FL_SELECT_BROWSER,5,155,425,285,"");
    fl_set_object_color(obj,FL_TOP_BCOL,FL_YELLOW);
    fl_set_object_lsize(obj,FL_NORMAL_SIZE);
  help_contents_browser = obj = fl_add_browser(FL_SELECT_BROWSER,5,30,210,120,"");
    fl_set_object_color(obj,FL_TOP_BCOL,FL_YELLOW);
    fl_set_object_lsize(obj,FL_NORMAL_SIZE);
  help_index_browser = obj = fl_add_browser(FL_SELECT_BROWSER,220,30,210,120,"");
    fl_set_object_color(obj,FL_TOP_BCOL,FL_YELLOW);
    fl_set_object_lsize(obj,FL_NORMAL_SIZE);
  obj = fl_add_text(FL_NORMAL_TEXT,5,0,175,25,"Contents");
    fl_set_object_color(obj,FL_DARKCYAN,FL_MCOL);
    fl_set_object_lcol(obj,FL_CYAN);
    fl_set_object_lsize(obj,FL_MEDIUM_SIZE);
    fl_set_object_lalign(obj,FL_ALIGN_CENTER);
    fl_set_object_lstyle(obj,FL_BOLD_STYLE);
  obj = fl_add_text(FL_NORMAL_TEXT,195,0,175,25,"Index");
    fl_set_object_color(obj,FL_DARKCYAN,FL_MCOL);
    fl_set_object_lcol(obj,FL_CYAN);
    fl_set_object_lsize(obj,FL_MEDIUM_SIZE);
    fl_set_object_lalign(obj,FL_ALIGN_CENTER);
    fl_set_object_lstyle(obj,FL_BOLD_STYLE);
  fl_end_form();

}
/*---------------------------------------*/

void create_the_forms(void)
{
  create_form_plot();
  create_form_blowup();
  create_form_activator();
  create_form_help();
}

