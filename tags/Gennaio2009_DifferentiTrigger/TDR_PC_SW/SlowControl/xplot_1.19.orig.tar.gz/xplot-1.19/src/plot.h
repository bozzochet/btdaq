#ifndef FD_plot_h_
#define FD_plot_h_
/* Header file generated with fdesign. */

/**** Callback routines ****/

extern void redraw_plots(FL_OBJECT *, long);
extern void set_autoredraw(FL_OBJECT *, long);
extern void guess_y(FL_OBJECT *, long);
extern void setlinetype(FL_OBJECT *, long);
extern void setrange(FL_OBJECT *, long);
extern void setboundary(FL_OBJECT *, long);
extern void activate_sets(FL_OBJECT *, long);
extern void dohelp(FL_OBJECT *, long);
extern void settitle(FL_OBJECT *, long);
extern void quit(FL_OBJECT *, long);
extern void do_blowup(FL_OBJECT *, long);

extern void quitblowup(FL_OBJECT *, long);

extern void setactive(FL_OBJECT *, long);
extern void activator_done(FL_OBJECT *, long);

extern void help_done(FL_OBJECT *, long);


/**** Forms and Objects ****/

extern FL_FORM *plot;

extern FL_OBJECT
        *small_plot,
        *autoredraw_button,
        *linetype_guess,
        *miny_slider,
        *maxy_slider,
        *minx_slider,
        *maxx_slider,
        *minx_input,
        *maxx_input,
        *miny_input,
        *maxy_input,
        *activate_button,
        *help_button;

extern FL_FORM *blowup;

extern FL_OBJECT
        *blowup_plot,
        *blowup_quit;

extern FL_FORM *activator;

extern FL_OBJECT
        *activate_browser;

extern FL_FORM *help;

extern FL_OBJECT
        *help_browser,
        *help_contents_browser,
        *help_index_browser;



/**** Creation Routine ****/

extern void create_the_forms(void);

#endif /* FD_plot_h_ */
